#!/bin/bash
# ================================================
# SwimTech 원클릭 설치 스크립트
# 지원 OS: Ubuntu 20.04/22.04/24.04, Debian 11/12
# 사용법: curl -sSL https://raw.githubusercontent.com/JinHyunjun/swimtech/main/install.sh | bash
# ================================================

set -e  # 오류 발생 시 즉시 종료

# ── 색상 정의 ────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# ── 함수 정의 ────────────────────────────────────
print_banner() {
    echo ""
    echo -e "${CYAN}"
    echo "  ███████╗██╗    ██╗██╗███╗   ███╗████████╗███████╗ ██████╗██╗  ██╗"
    echo "  ██╔════╝██║    ██║██║████╗ ████║╚══██╔══╝██╔════╝██╔════╝██║  ██║"
    echo "  ███████╗██║ █╗ ██║██║██╔████╔██║   ██║   █████╗  ██║     ███████║"
    echo "  ╚════██║██║███╗██║██║██║╚██╔╝██║   ██║   ██╔══╝  ██║     ██╔══██║"
    echo "  ███████║╚███╔███╔╝██║██║ ╚═╝ ██║   ██║   ███████╗╚██████╗██║  ██║"
    echo "  ╚══════╝ ╚══╝╚══╝ ╚═╝╚═╝     ╚═╝   ╚═╝   ╚══════╝ ╚═════╝╚═╝  ╚═╝"
    echo -e "${NC}"
    echo -e "${GREEN}  🏊 수영 영법 AI 분석 플랫폼 — 원클릭 설치 스크립트${NC}"
    echo ""
}

print_step() {
    echo -e "\n${BLUE}[STEP $1]${NC} $2"
}

print_ok() {
    echo -e "${GREEN}  ✅ $1${NC}"
}

print_warn() {
    echo -e "${YELLOW}  ⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}  ❌ $1${NC}"
}

check_os() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS=$ID
        VER=$VERSION_ID
    else
        print_error "지원하지 않는 운영체제입니다."
        exit 1
    fi

    case $OS in
        ubuntu|debian)
            print_ok "OS 확인: $PRETTY_NAME"
            ;;
        *)
            print_warn "테스트되지 않은 OS입니다: $PRETTY_NAME (계속 진행합니다)"
            ;;
    esac
}

check_root() {
    if [ "$EUID" -ne 0 ]; then
        print_error "root 권한이 필요합니다. 다음 명령어로 실행하세요:"
        echo "  sudo bash install.sh"
        exit 1
    fi
}

install_docker() {
    print_step 1 "Docker 설치 확인"

    if command -v docker &> /dev/null; then
        DOCKER_VER=$(docker --version | awk '{print $3}' | tr -d ',')
        print_ok "Docker 이미 설치됨: v$DOCKER_VER"
    else
        echo "  Docker를 설치합니다..."

        # 이전 버전 제거
        apt-get remove -y docker docker-engine docker.io containerd runc 2>/dev/null || true

        # 의존성 설치
        apt-get update -qq
        apt-get install -y -qq \
            ca-certificates \
            curl \
            gnupg \
            lsb-release

        # Docker GPG 키 추가
        install -m 0755 -d /etc/apt/keyrings
        curl -fsSL https://download.docker.com/linux/$OS/gpg | \
            gpg --dearmor -o /etc/apt/keyrings/docker.gpg
        chmod a+r /etc/apt/keyrings/docker.gpg

        # Docker 저장소 추가
        echo \
            "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
            https://download.docker.com/linux/$OS \
            $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
            tee /etc/apt/sources.list.d/docker.list > /dev/null

        # Docker 설치
        apt-get update -qq
        apt-get install -y -qq \
            docker-ce \
            docker-ce-cli \
            containerd.io \
            docker-buildx-plugin \
            docker-compose-plugin

        # Docker 서비스 시작
        systemctl enable docker
        systemctl start docker

        print_ok "Docker 설치 완료"
    fi
}

install_docker_compose() {
    print_step 2 "Docker Compose 설치 확인"

    if docker compose version &> /dev/null; then
        print_ok "Docker Compose 이미 설치됨 (플러그인)"
    elif command -v docker-compose &> /dev/null; then
        print_ok "Docker Compose 이미 설치됨 (standalone)"
    else
        echo "  Docker Compose를 설치합니다..."
        apt-get install -y -qq docker-compose-plugin
        print_ok "Docker Compose 설치 완료"
    fi
}

install_git() {
    print_step 3 "Git 설치 확인"

    if command -v git &> /dev/null; then
        GIT_VER=$(git --version | awk '{print $3}')
        print_ok "Git 이미 설치됨: v$GIT_VER"
    else
        echo "  Git을 설치합니다..."
        apt-get install -y -qq git
        print_ok "Git 설치 완료"
    fi
}

clone_repo() {
    print_step 4 "SwimTech 코드 다운로드"

    INSTALL_DIR="/opt/swimtech"

    if [ -d "$INSTALL_DIR" ]; then
        print_warn "$INSTALL_DIR 폴더가 이미 존재합니다."
        read -p "  기존 폴더를 삭제하고 새로 설치할까요? [y/N]: " confirm
        if [[ $confirm =~ ^[Yy]$ ]]; then
            rm -rf "$INSTALL_DIR"
        else
            echo "  기존 폴더를 유지합니다. 업데이트만 진행합니다."
            cd "$INSTALL_DIR"
            git pull origin main
            return
        fi
    fi

    git clone https://github.com/JinHyunjun/swimtech.git "$INSTALL_DIR"
    cd "$INSTALL_DIR"
    print_ok "코드 다운로드 완료: $INSTALL_DIR"
}

setup_env() {
    print_step 5 "환경 변수 설정"

    INSTALL_DIR="/opt/swimtech"
    ENV_FILE="$INSTALL_DIR/.env"

    if [ -f "$ENV_FILE" ]; then
        print_warn ".env 파일이 이미 존재합니다. 기존 설정을 유지합니다."
        return
    fi

    # 랜덤 비밀 키 생성
    SECRET_KEY=$(openssl rand -hex 32)

    cat > "$ENV_FILE" << EOF
# ================================================
# SwimTech 환경 변수
# ================================================

HOST_IP=0.0.0.0

# PostgreSQL
POSTGRES_USER=swimtech
POSTGRES_PASSWORD=swimtech1234
POSTGRES_DB=swimtech

# MinIO
MINIO_ROOT_USER=minioadmin
MINIO_ROOT_PASSWORD=minioadmin123

# Metabase DB
MB_DB_TYPE=postgres
MB_DB_HOST=postgres
MB_DB_PORT=5432
MB_DB_DBNAME=metabase
MB_DB_USER=swimtech
MB_DB_PASS=swimtech1234

# 포트 (4xxxx 규칙)
API_EXTERNAL_PORT=48000
POSTGRES_EXTERNAL_PORT=45433
METABASE_EXTERNAL_PORT=43001
MINIO_API_EXTERNAL_PORT=49000
MINIO_CONSOLE_EXTERNAL_PORT=49001
FLOWER_EXTERNAL_PORT=45555
REDIS_EXTERNAL_PORT=46379

# JWT
SECRET_KEY=$SECRET_KEY
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=60

# 관리자 계정
ADMIN_ID=admin
ADMIN_PW=swimtech1234
EOF

    print_ok ".env 파일 생성 완료"
    print_warn "보안을 위해 $ENV_FILE 에서 비밀번호를 변경하세요!"
}

start_services() {
    print_step 6 "SwimTech 서비스 시작"

    INSTALL_DIR="/opt/swimtech"
    cd "$INSTALL_DIR"

    echo "  Docker 이미지를 빌드하고 서비스를 시작합니다..."
    echo "  (처음 실행 시 5~10분 소요될 수 있습니다)"

    docker compose pull 2>/dev/null || true
    docker compose up -d --build

    print_ok "서비스 시작 완료"
}

wait_for_services() {
    print_step 7 "서비스 준비 대기"

    echo "  서비스가 준비될 때까지 기다립니다..."

    # PostgreSQL 준비 대기 (최대 60초)
    for i in $(seq 1 30); do
        if docker compose exec -T postgres pg_isready -U swimtech -d swimtech &>/dev/null; then
            print_ok "PostgreSQL 준비 완료"
            break
        fi
        sleep 2
        echo -n "."
    done
    echo ""

    # API 준비 대기 (최대 60초)
    for i in $(seq 1 30); do
        if curl -s http://localhost:48000/api/health &>/dev/null; then
            print_ok "API 서버 준비 완료"
            break
        fi
        sleep 2
        echo -n "."
    done
    echo ""
}

print_result() {
    echo ""
    echo -e "${GREEN}================================================${NC}"
    echo -e "${GREEN}  🎉 SwimTech 설치 완료!${NC}"
    echo -e "${GREEN}================================================${NC}"
    echo ""
    echo -e "${CYAN}  📌 접속 주소${NC}"
    echo "  ┌─────────────────────────────────────────┐"
    echo "  │  메인 서비스    https://localhost        │"
    echo "  │  대시보드       https://localhost/dash   │"
    echo "  │  Metabase       http://localhost:43001   │"
    echo "  │  MinIO 콘솔     http://localhost:49001   │"
    echo "  └─────────────────────────────────────────┘"
    echo ""
    echo -e "${CYAN}  🔑 기본 계정${NC}"
    echo "  ┌─────────────────────────────────────────┐"
    echo "  │  아이디: admin                          │"
    echo "  │  비밀번호: swimtech1234                 │"
    echo "  │  (설치 후 반드시 변경하세요!)           │"
    echo "  └─────────────────────────────────────────┘"
    echo ""
    echo -e "${CYAN}  📁 설치 경로${NC}"
    echo "  /opt/swimtech"
    echo ""
    echo -e "${CYAN}  🛠️  유용한 명령어${NC}"
    echo "  cd /opt/swimtech"
    echo "  docker compose ps          # 상태 확인"
    echo "  docker compose logs -f     # 로그 보기"
    echo "  docker compose down        # 서비스 중지"
    echo "  docker compose up -d       # 서비스 시작"
    echo ""
    echo -e "${YELLOW}  ⚠️  보안 설정${NC}"
    echo "  /opt/swimtech/.env 파일에서 비밀번호를 변경하세요."
    echo ""
}

# ── 메인 실행 ────────────────────────────────────
main() {
    print_banner
    check_root
    check_os
    install_docker
    install_docker_compose
    install_git
    clone_repo
    setup_env
    start_services
    wait_for_services
    print_result
}

main "$@"
