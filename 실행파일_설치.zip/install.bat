@echo off
chcp 65001 > nul
setlocal EnableDelayedExpansion

:: ================================================
:: SwimTech Windows 원클릭 설치 스크립트
:: 지원 OS: Windows 10/11
:: 사용법: install.bat 을 관리자 권한으로 실행
:: ================================================

title SwimTech 설치 프로그램

echo.
echo   ███████╗██╗    ██╗██╗███╗   ███╗████████╗███████╗ ██████╗██╗  ██╗
echo   ██╔════╝██║    ██║██║████╗ ████║╚══██╔══╝██╔════╝██╔════╝██║  ██║
echo   ███████╗██║ █╗ ██║██║██╔████╔██║   ██║   █████╗  ██║     ███████║
echo   ╚════██║██║███╗██║██║██║╚██╔╝██║   ██║   ██╔══╝  ██║     ██╔══██║
echo   ███████║╚███╔███╔╝██║██║ ╚═╝ ██║   ██║   ███████╗╚██████╗██║  ██║
echo   ╚══════╝ ╚══╝╚══╝ ╚═╝╚═╝     ╚═╝   ╚═╝   ╚══════╝ ╚═════╝╚═╝  ╚═╝
echo.
echo   🏊 수영 영법 AI 분석 플랫폼 - Windows 설치 프로그램
echo   =====================================================
echo.

:: 관리자 권한 확인
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo   ❌ 관리자 권한이 필요합니다.
    echo   이 파일을 우클릭 후 "관리자 권한으로 실행" 을 선택하세요.
    pause
    exit /b 1
)

set INSTALL_DIR=C:\swimtech

:: ── STEP 1: winget 확인 ──────────────────────────
echo   [STEP 1] winget 확인 중...
winget --version >nul 2>&1
if %errorLevel% neq 0 (
    echo   ❌ winget이 설치되어 있지 않습니다.
    echo   Windows 앱 설치 관리자를 Microsoft Store에서 설치해주세요.
    echo   https://apps.microsoft.com/store/detail/app-installer/9NBLGGH4NNS1
    pause
    exit /b 1
)
echo   ✅ winget 확인 완료

:: ── STEP 2: Git 설치 ─────────────────────────────
echo.
echo   [STEP 2] Git 설치 확인 중...
git --version >nul 2>&1
if %errorLevel% neq 0 (
    echo   Git을 설치합니다...
    winget install --id Git.Git -e --source winget --silent
    if %errorLevel% neq 0 (
        echo   ❌ Git 설치 실패. 수동으로 설치해주세요: https://git-scm.com
        pause
        exit /b 1
    )
    :: PATH 새로고침
    call RefreshEnv.cmd 2>nul || (
        set "PATH=%PATH%;C:\Program Files\Git\bin"
    )
    echo   ✅ Git 설치 완료
) else (
    for /f "tokens=3" %%i in ('git --version') do set GIT_VER=%%i
    echo   ✅ Git 이미 설치됨: v!GIT_VER!
)

:: ── STEP 3: Docker Desktop 설치 ──────────────────
echo.
echo   [STEP 3] Docker Desktop 설치 확인 중...
docker --version >nul 2>&1
if %errorLevel% neq 0 (
    echo   Docker Desktop을 설치합니다...
    echo   ⚠️  설치 후 재부팅이 필요할 수 있습니다.
    winget install --id Docker.DockerDesktop -e --source winget --silent
    if %errorLevel% neq 0 (
        echo   ❌ Docker Desktop 설치 실패.
        echo   수동으로 설치해주세요: https://www.docker.com/products/docker-desktop
        pause
        exit /b 1
    )
    echo   ✅ Docker Desktop 설치 완료
    echo.
    echo   ⚠️  Docker Desktop을 실행하고 WSL2 설정을 완료한 후
    echo      이 스크립트를 다시 실행해주세요.
    echo.
    echo   Docker Desktop 실행 후 트레이 아이콘이 초록색이 되면
    echo   이 창을 닫고 install.bat 을 다시 실행하세요.
    pause
    exit /b 0
) else (
    for /f "tokens=3" %%i in ('docker --version') do set DOCKER_VER=%%i
    echo   ✅ Docker 이미 설치됨: v!DOCKER_VER!
)

:: Docker 실행 확인
docker info >nul 2>&1
if %errorLevel% neq 0 (
    echo   ⚠️  Docker Desktop이 실행 중이 아닙니다.
    echo   Docker Desktop을 실행하고 트레이 아이콘이 초록색이 될 때까지 기다린 후
    echo   이 스크립트를 다시 실행하세요.
    pause
    exit /b 1
)

:: ── STEP 4: 코드 다운로드 ────────────────────────
echo.
echo   [STEP 4] SwimTech 코드 다운로드 중...

if exist "%INSTALL_DIR%" (
    echo   ⚠️  %INSTALL_DIR% 폴더가 이미 존재합니다.
    set /p CONFIRM="   기존 폴더를 삭제하고 새로 설치할까요? [y/N]: "
    if /i "!CONFIRM!"=="y" (
        rmdir /s /q "%INSTALL_DIR%"
        git clone https://github.com/JinHyunjun/swimtech.git "%INSTALL_DIR%"
    ) else (
        echo   기존 폴더를 유지합니다. 업데이트만 진행합니다.
        cd /d "%INSTALL_DIR%"
        git pull origin main
    )
) else (
    git clone https://github.com/JinHyunjun/swimtech.git "%INSTALL_DIR%"
)

if %errorLevel% neq 0 (
    echo   ❌ 코드 다운로드 실패. 인터넷 연결을 확인해주세요.
    pause
    exit /b 1
)
echo   ✅ 코드 다운로드 완료: %INSTALL_DIR%

:: ── STEP 5: 환경 변수 설정 ───────────────────────
echo.
echo   [STEP 5] 환경 변수 설정 중...

if not exist "%INSTALL_DIR%\.env" (
    :: 랜덤 SECRET_KEY 생성
    set "CHARS=abcdefghijklmnopqrstuvwxyz0123456789"
    set "SECRET_KEY="
    for /L %%i in (1,1,32) do (
        set /a "IDX=!RANDOM! %% 36"
        for %%j in (!IDX!) do (
            set "SECRET_KEY=!SECRET_KEY!!CHARS:~%%j,1!"
        )
    )

    (
        echo # ================================================
        echo # SwimTech 환경 변수
        echo # ================================================
        echo.
        echo HOST_IP=0.0.0.0
        echo.
        echo # PostgreSQL
        echo POSTGRES_USER=swimtech
        echo POSTGRES_PASSWORD=swimtech1234
        echo POSTGRES_DB=swimtech
        echo.
        echo # MinIO
        echo MINIO_ROOT_USER=minioadmin
        echo MINIO_ROOT_PASSWORD=minioadmin123
        echo.
        echo # Metabase DB
        echo MB_DB_TYPE=postgres
        echo MB_DB_HOST=postgres
        echo MB_DB_PORT=5432
        echo MB_DB_DBNAME=metabase
        echo MB_DB_USER=swimtech
        echo MB_DB_PASS=swimtech1234
        echo.
        echo # 포트 ^(4xxxx 규칙^)
        echo API_EXTERNAL_PORT=48000
        echo POSTGRES_EXTERNAL_PORT=45433
        echo METABASE_EXTERNAL_PORT=43001
        echo MINIO_API_EXTERNAL_PORT=49000
        echo MINIO_CONSOLE_EXTERNAL_PORT=49001
        echo FLOWER_EXTERNAL_PORT=45555
        echo REDIS_EXTERNAL_PORT=46379
        echo.
        echo # JWT
        echo SECRET_KEY=!SECRET_KEY!
        echo ALGORITHM=HS256
        echo ACCESS_TOKEN_EXPIRE_MINUTES=60
        echo.
        echo # 관리자 계정
        echo ADMIN_ID=admin
        echo ADMIN_PW=swimtech1234
    ) > "%INSTALL_DIR%\.env"

    echo   ✅ .env 파일 생성 완료
    echo   ⚠️  보안을 위해 %INSTALL_DIR%\.env 에서 비밀번호를 변경하세요!
) else (
    echo   ✅ .env 파일 이미 존재 ^(기존 설정 유지^)
)

:: ── STEP 6: 서비스 시작 ──────────────────────────
echo.
echo   [STEP 6] SwimTech 서비스 시작 중...
echo   ^(처음 실행 시 5~10분 소요될 수 있습니다^)
echo.

cd /d "%INSTALL_DIR%"
docker compose up -d --build

if %errorLevel% neq 0 (
    echo   ❌ 서비스 시작 실패. 로그를 확인해주세요:
    echo   docker compose logs
    pause
    exit /b 1
)

:: ── STEP 7: 준비 대기 ────────────────────────────
echo.
echo   [STEP 7] 서비스 준비 대기 중...

set /a COUNT=0
:WAIT_LOOP
if !COUNT! geq 30 goto WAIT_DONE
docker compose exec -T postgres pg_isready -U swimtech -d swimtech >nul 2>&1
if %errorLevel% equ 0 goto WAIT_DONE
set /a COUNT+=1
echo   . 대기 중... (!COUNT!/30)
timeout /t 2 /nobreak >nul
goto WAIT_LOOP

:WAIT_DONE
echo   ✅ 서비스 준비 완료

:: ── 완료 메시지 ──────────────────────────────────
echo.
echo   ================================================
echo   🎉 SwimTech 설치 완료!
echo   ================================================
echo.
echo   📌 접속 주소
echo   ┌─────────────────────────────────────────────┐
echo   │  메인 서비스    https://localhost            │
echo   │  대시보드       https://localhost/dashboard  │
echo   │  Metabase       http://localhost:43001       │
echo   │  MinIO 콘솔     http://localhost:49001       │
echo   └─────────────────────────────────────────────┘
echo.
echo   🔑 기본 계정
echo   ┌─────────────────────────────────────────────┐
echo   │  아이디: admin                              │
echo   │  비밀번호: swimtech1234                     │
echo   │  (설치 후 반드시 변경하세요!)               │
echo   └─────────────────────────────────────────────┘
echo.
echo   📁 설치 경로: %INSTALL_DIR%
echo.
echo   🛠️  유용한 명령어 (PowerShell)
echo   cd %INSTALL_DIR%
echo   docker compose ps          # 상태 확인
echo   docker compose logs -f     # 로그 보기
echo   docker compose down        # 서비스 중지
echo   docker compose up -d       # 서비스 시작
echo.

set /p OPEN_BROWSER="   지금 브라우저에서 SwimTech를 여시겠습니까? [Y/n]: "
if /i not "!OPEN_BROWSER!"=="n" (
    start https://localhost
)

pause
endlocal
